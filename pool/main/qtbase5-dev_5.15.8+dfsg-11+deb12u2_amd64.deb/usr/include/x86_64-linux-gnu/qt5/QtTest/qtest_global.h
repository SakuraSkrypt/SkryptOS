#ifndef DEPRECATED_HEADER_QtTest_qtest_global_h
#define DEPRECATED_HEADER_QtTest_qtest_global_h
#if defined(__GNUC__)
#  warning Header <QtTest/qtest_global.h> is deprecated. Please include <QtTest/qttestglobal.h> instead.
#elif defined(_MSC_VER)
#  pragma message ("Header <QtTest/qtest_global.h> is deprecated. Please include <QtTest/qttestglobal.h> instead.")
#endif
#include <QtTest/qttestglobal.h>
#if 0
#pragma qt_no_master_include
#endif
#endif
